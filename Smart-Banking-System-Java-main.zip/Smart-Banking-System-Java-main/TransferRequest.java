public class TransferRequest {

    private final long fromAccount;
    private final long toAccount;
    private final double amount;

    public TransferRequest(
            long fromAccount,
            long toAccount,
            double amount) {

        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.amount = amount;
    }

    public long getFromAccount() {
        return fromAccount;
    }

    public long getToAccount() {
        return toAccount;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {

        return "Transfer "
                + fromAccount
                + " -> "
                + toAccount
                + " | ₹"
                + amount;
    }
}