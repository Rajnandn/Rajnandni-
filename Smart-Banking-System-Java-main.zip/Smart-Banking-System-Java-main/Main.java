import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {

        Bank bank = new Bank();

        bank.loadData();

        SwingUtilities.invokeLater(() -> {

            BankingGUI gui =
                    new BankingGUI(bank);

            gui.setVisible(true);
        });
    }
}