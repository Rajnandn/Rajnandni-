import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class BankingGUI extends JFrame {

    private final Bank bank;

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(cardLayout);

    private final Color SIDEBAR = new Color(20, 29, 45);
    private final Color SIDEBAR_BUTTON = new Color(31, 43, 63);
    private final Color ACCENT = new Color(34, 197, 94);
    private final Color BACKGROUND = new Color(245, 247, 250);
    private final Color TEXT = new Color(31, 41, 55);
    private final Color SECONDARY = new Color(107, 114, 128);

    public BankingGUI(Bank bank) {

        this.bank = bank;

        setTitle("Smart Banking Management System");

        setSize(1150, 720);

        setMinimumSize(
                new Dimension(1000, 650)
        );

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);

        buildUI();
    }

    // =====================================================
    // MAIN UI
    // =====================================================

    private void buildUI() {

        setLayout(
                new BorderLayout()
        );

        add(
                createSidebar(),
                BorderLayout.WEST
        );

        contentPanel.setBackground(
                BACKGROUND
        );

        contentPanel.add(
                createDashboard(),
                "Dashboard"
        );

        contentPanel.add(
                createAccountPanel(),
                "Create Account"
        );

        contentPanel.add(
                createDepositPanel(),
                "Deposit"
        );

        contentPanel.add(
                createWithdrawPanel(),
                "Withdraw"
        );

        contentPanel.add(
                createTransferPanel(),
                "Transfer"
        );

        contentPanel.add(
                createBalancePanel(),
                "Balance"
        );

        contentPanel.add(
                createHistoryPanel(),
                "History"
        );

        contentPanel.add(
                createSearchPanel(),
                "Search"
        );

        contentPanel.add(
                createPendingPanel(),
                "Pending"
        );

        contentPanel.add(
                createUndoPanel(),
                "Undo"
        );

        contentPanel.add(
                createAllAccountsPanel(),
                "All Accounts"
        );

        add(
                contentPanel,
                BorderLayout.CENTER
        );
    }

    // =====================================================
    // SIDEBAR
    // =====================================================

    private JPanel createSidebar() {

        JPanel sidebar = new JPanel();

        sidebar.setPreferredSize(
                new Dimension(235, 720)
        );

        sidebar.setBackground(
                SIDEBAR
        );

        sidebar.setLayout(
                new BorderLayout()
        );

        // ---------- LOGO ----------

        JPanel top = new JPanel();

        top.setOpaque(false);

        top.setBorder(
                new EmptyBorder(
                        25,
                        18,
                        18,
                        18
                )
        );

        top.setLayout(
                new BoxLayout(
                        top,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel bankText =
                new JLabel("BANKING");

        bankText.setForeground(
                ACCENT
        );

        bankText.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        JLabel title =
                new JLabel(
                        "SMART BANKING"
                );

        title.setForeground(
                Color.WHITE
        );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        20
                )
        );

        JLabel subtitle =
                new JLabel(
                        "Java • DSA • Multithreading"
                );

        subtitle.setForeground(
                new Color(
                        170,
                        183,
                        200
                )
        );

        subtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        11
                )
        );

        top.add(bankText);

        top.add(title);

        top.add(
                Box.createVerticalStrut(5)
        );

        top.add(subtitle);

        sidebar.add(
                top,
                BorderLayout.NORTH
        );

        // ---------- MENU ----------

        JPanel menu = new JPanel();

        menu.setOpaque(false);

        menu.setBorder(
                new EmptyBorder(
                        5,
                        12,
                        10,
                        12
                )
        );

        menu.setLayout(
                new GridLayout(
                        0,
                        1,
                        0,
                        6
                )
        );

        addMenuButton(
                menu,
                "Dashboard",
                "Dashboard"
        );

        addMenuButton(
                menu,
                "Create Account",
                "Create Account"
        );

        addMenuButton(
                menu,
                "Deposit Money",
                "Deposit"
        );

        addMenuButton(
                menu,
                "Withdraw Money",
                "Withdraw"
        );

        addMenuButton(
                menu,
                "Transfer Money",
                "Transfer"
        );

        addMenuButton(
                menu,
                "Check Balance",
                "Balance"
        );

        addMenuButton(
                menu,
                "Transaction History",
                "History"
        );

        addMenuButton(
                menu,
                "Search Account",
                "Search"
        );

        addMenuButton(
                menu,
                "Pending Transfers",
                "Pending"
        );

        addMenuButton(
                menu,
                "Undo Operation",
                "Undo"
        );

        addMenuButton(
                menu,
                "All Accounts",
                "All Accounts"
        );

        sidebar.add(
                menu,
                BorderLayout.CENTER
        );

        // ---------- EXIT ----------

        JButton exitButton =
                new JButton(
                        "Exit & Save"
                );

        styleMenuButton(
                exitButton
        );

        exitButton.addActionListener(
                e -> {

                    bank.saveData();

                    JOptionPane.showMessageDialog(
                            this,
                            "Banking data saved successfully.",
                            "Exit",
                            JOptionPane.INFORMATION_MESSAGE
                    );

                    System.exit(0);
                }
        );

        JPanel bottom =
                new JPanel(
                        new BorderLayout()
                );

        bottom.setOpaque(false);

        bottom.setBorder(
                new EmptyBorder(
                        10,
                        12,
                        18,
                        12
                )
        );

        bottom.add(
                exitButton,
                BorderLayout.CENTER
        );

        sidebar.add(
                bottom,
                BorderLayout.SOUTH
        );

        return sidebar;
    }

    private void addMenuButton(
            JPanel menu,
            String text,
            String page
    ) {

        JButton button =
                new JButton(text);

        styleMenuButton(
                button
        );

        button.addActionListener(
                e -> cardLayout.show(
                        contentPanel,
                        page
                )
        );

        menu.add(button);
    }

    private void styleMenuButton(
            JButton button
    ) {

        button.setHorizontalAlignment(
                SwingConstants.LEFT
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                SIDEBAR_BUTTON
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setBorder(
                new EmptyBorder(
                        11,
                        14,
                        11,
                        10
                )
        );

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );
    }

    // =====================================================
    // DASHBOARD
    // =====================================================

    private JPanel createDashboard() {

        JPanel panel =
                basePanel(
                        "Welcome to Smart Banking",
                        "Manage your banking activities securely and easily."
                );

        JPanel body =
                new JPanel();

        body.setOpaque(false);

        body.setLayout(
                new BoxLayout(
                        body,
                        BoxLayout.Y_AXIS
                )
        );

        body.setBorder(
                new EmptyBorder(
                        30,
                        0,
                        0,
                        0
                )
        );

        // ---------- WELCOME CARD ----------

        JPanel welcomeCard =
                new JPanel(
                        new BorderLayout()
                );

        welcomeCard.setBackground(
                SIDEBAR
        );

        welcomeCard.setBorder(
                new EmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );

        JLabel welcomeTitle =
                new JLabel(
                        "Your Banking, Simplified."
                );

        welcomeTitle.setForeground(
                Color.WHITE
        );

        welcomeTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        JLabel welcomeText =
                new JLabel(
                        "Create accounts, manage money, transfer funds and track transactions."
                );

        welcomeText.setForeground(
                new Color(
                        200,
                        210,
                        225
                )
        );

        welcomeText.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        JPanel welcomeContent =
                new JPanel();

        welcomeContent.setOpaque(false);

        welcomeContent.setLayout(
                new BoxLayout(
                        welcomeContent,
                        BoxLayout.Y_AXIS
                )
        );

        welcomeContent.add(
                welcomeTitle
        );

        welcomeContent.add(
                Box.createVerticalStrut(8)
        );

        welcomeContent.add(
                welcomeText
        );

        welcomeCard.add(
                welcomeContent,
                BorderLayout.WEST
        );

        body.add(
                welcomeCard
        );

        body.add(
                Box.createVerticalStrut(25)
        );

        // ---------- QUICK ACTIONS ----------

        JPanel quickActions =
                new JPanel(
                        new GridLayout(
                                1,
                                3,
                                18,
                                0
                        )
                );

        quickActions.setOpaque(false);

        quickActions.add(
                dashboardCard(
                        "Create Account",
                        "Open a new bank account.",
                        "Create Account"
                )
        );

        quickActions.add(
                dashboardCard(
                        "Deposit Money",
                        "Add money to your account.",
                        "Deposit"
                )
        );

        quickActions.add(
                dashboardCard(
                        "Transfer Money",
                        "Send money to another account.",
                        "Transfer"
                )
        );

        body.add(
                quickActions
        );

        body.add(
                Box.createVerticalStrut(25)
        );

        // ---------- BANKING SERVICES ----------

        JPanel services =
                new JPanel();

        services.setBackground(
                Color.WHITE
        );

        services.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        225,
                                        229,
                                        235
                                )
                        ),
                        new EmptyBorder(
                                22,
                                25,
                                22,
                                25
                        )
                )
        );

        services.setLayout(
                new BoxLayout(
                        services,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel servicesTitle =
                new JLabel(
                        "Banking Services"
                );

        servicesTitle.setForeground(
                TEXT
        );

        servicesTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        19
                )
        );

        JLabel servicesText =
                new JLabel(
                        "Choose an option from the menu to manage your account."
                );

        servicesText.setForeground(
                SECONDARY
        );

        servicesText.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        services.add(
                servicesTitle
        );

        services.add(
                Box.createVerticalStrut(7)
        );

        services.add(
                servicesText
        );

        services.add(
                Box.createVerticalStrut(18)
        );

        JPanel serviceRow =
                new JPanel(
                        new GridLayout(
                                1,
                                3,
                                15,
                                0
                        )
                );

        serviceRow.setOpaque(false);

        serviceRow.add(
                serviceBox(
                        "Check Balance"
                )
        );

        serviceRow.add(
                serviceBox(
                        "Transaction History"
                )
        );

        serviceRow.add(
                serviceBox(
                        "Search Account"
                )
        );

        services.add(
                serviceRow
        );

        body.add(
                services
        );

        panel.add(
                body,
                BorderLayout.CENTER
        );

        return panel;
    }

    private JPanel dashboardCard(
            String title,
            String description,
            String page
    ) {

        JPanel card =
                new JPanel();

        card.setBackground(
                Color.WHITE
        );

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        225,
                                        229,
                                        235
                                )
                        ),
                        new EmptyBorder(
                                20,
                                20,
                                20,
                                20
                        )
                )
        );

        card.setLayout(
                new BoxLayout(
                        card,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel titleLabel =
                new JLabel(
                        title
                );

        titleLabel.setForeground(
                TEXT
        );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        17
                )
        );

        JLabel descriptionLabel =
                new JLabel(
                        "<html>"
                                + description
                                + "</html>"
                );

        descriptionLabel.setForeground(
                SECONDARY
        );

        descriptionLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        12
                )
        );

        JButton button =
                actionButton(
                        "Open"
                );

        button.addActionListener(
                e -> cardLayout.show(
                        contentPanel,
                        page
                )
        );

        card.add(
                titleLabel
        );

        card.add(
                Box.createVerticalStrut(7)
        );

        card.add(
                descriptionLabel
        );

        card.add(
                Box.createVerticalStrut(15)
        );

        card.add(
                button
        );

        return card;
    }

    private JPanel serviceBox(
            String text
    ) {

        JPanel box =
                new JPanel(
                        new BorderLayout()
                );

        box.setBackground(
                new Color(
                        248,
                        250,
                        252
                )
        );

        box.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        230,
                                        233,
                                        238
                                )
                        ),
                        new EmptyBorder(
                                12,
                                15,
                                12,
                                15
                        )
                )
        );

        JLabel label =
                new JLabel(
                        text
                );

        label.setForeground(
                TEXT
        );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        box.add(
                label,
                BorderLayout.CENTER
        );

        return box;
    }

    // =====================================================
    // CREATE ACCOUNT
    // =====================================================

    private JPanel createAccountPanel() {

        JPanel panel =
                basePanel(
                        "Create New Account",
                        "Register a customer and open a new bank account."
                );

        JPanel card =
                formCard();

        JTextField name =
                field();

        JTextField phone =
                field();

        JTextField amount =
                field();

        card.add(
                fieldLabel(
                        "Customer Name"
                )
        );

        card.add(name);

        card.add(
                fieldLabel(
                        "Phone Number"
                )
        );

        card.add(phone);

        card.add(
                fieldLabel(
                        "Initial Deposit"
                )
        );

        card.add(amount);

        card.add(
                Box.createVerticalStrut(
                        18
                )
        );

        JButton create =
                actionButton(
                        "Create Account"
                );

        create.addActionListener(
                e -> {

                    try {

                        String customerName =
                                name.getText()
                                        .trim();

                        String customerPhone =
                                phone.getText()
                                        .trim();

                        double initialDeposit =
                                Double.parseDouble(
                                        amount.getText()
                                                .trim()
                                );

                        if (
                                customerName.isEmpty()
                                        ||
                                customerPhone.isEmpty()
                        ) {

                            throw new Exception(
                                    "Name and phone number are required."
                            );
                        }

                        bank.createAccount(
                                customerName,
                                customerPhone,
                                initialDeposit
                        );

                        success(
                                "Account created successfully!"
                        );

                        name.setText("");

                        phone.setText("");

                        amount.setText("");

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                create
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // DEPOSIT
    // =====================================================

    private JPanel createDepositPanel() {

        JPanel panel =
                basePanel(
                        "Deposit Money",
                        "Add money to an existing bank account."
                );

        JPanel card =
                formCard();

        JTextField account =
                field();

        JTextField amount =
                field();

        card.add(
                fieldLabel(
                        "Account Number"
                )
        );

        card.add(account);

        card.add(
                fieldLabel(
                        "Amount"
                )
        );

        card.add(amount);

        card.add(
                Box.createVerticalStrut(
                        18
                )
        );

        JButton deposit =
                actionButton(
                        "Deposit Money"
                );

        deposit.addActionListener(
                e -> {

                    try {

                        long accountNumber =
                                Long.parseLong(
                                        account.getText()
                                                .trim()
                                );

                        double money =
                                Double.parseDouble(
                                        amount.getText()
                                                .trim()
                                );

                        bank.deposit(
                                accountNumber,
                                money
                        );

                        success(
                                "Money deposited successfully!"
                        );

                        account.setText("");

                        amount.setText("");

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                deposit
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // WITHDRAW
    // =====================================================

    private JPanel createWithdrawPanel() {

        JPanel panel =
                basePanel(
                        "Withdraw Money",
                        "Withdraw money after balance validation."
                );

        JPanel card =
                formCard();

        JTextField account =
                field();

        JTextField amount =
                field();

        card.add(
                fieldLabel(
                        "Account Number"
                )
        );

        card.add(account);

        card.add(
                fieldLabel(
                        "Amount"
                )
        );

        card.add(amount);

        card.add(
                Box.createVerticalStrut(
                        18
                )
        );

        JButton withdraw =
                actionButton(
                        "Withdraw Money"
                );

        withdraw.addActionListener(
                e -> {

                    try {

                        long accountNumber =
                                Long.parseLong(
                                        account.getText()
                                                .trim()
                                );

                        double money =
                                Double.parseDouble(
                                        amount.getText()
                                                .trim()
                                );

                        bank.withdraw(
                                accountNumber,
                                money
                        );

                        success(
                                "Money withdrawn successfully!"
                        );

                        account.setText("");

                        amount.setText("");

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                withdraw
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // TRANSFER
    // =====================================================

    private JPanel createTransferPanel() {

        JPanel panel =
                basePanel(
                        "Transfer Money",
                        "Transfer funds between two bank accounts."
                );

        JPanel card =
                formCard();

        JTextField sender =
                field();

        JTextField receiver =
                field();

        JTextField amount =
                field();

        card.add(
                fieldLabel(
                        "Sender Account"
                )
        );

        card.add(sender);

        card.add(
                fieldLabel(
                        "Receiver Account"
                )
        );

        card.add(receiver);

        card.add(
                fieldLabel(
                        "Amount"
                )
        );

        card.add(amount);

        card.add(
                Box.createVerticalStrut(
                        18
                )
        );

        JButton transfer =
                actionButton(
                        "Transfer Money"
                );

        transfer.addActionListener(
                e -> {

                    try {

                        long senderAccount =
                                Long.parseLong(
                                        sender.getText()
                                                .trim()
                                );

                        long receiverAccount =
                                Long.parseLong(
                                        receiver.getText()
                                                .trim()
                                );

                        double money =
                                Double.parseDouble(
                                        amount.getText()
                                                .trim()
                                );

                        bank.transfer(
                                senderAccount,
                                receiverAccount,
                                money
                        );

                        success(
                                "Money transferred successfully!"
                        );

                        sender.setText("");

                        receiver.setText("");

                        amount.setText("");

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                transfer
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // BALANCE
    // =====================================================

    private JPanel createBalancePanel() {

        JPanel panel =
                basePanel(
                        "Check Balance",
                        "View the current balance of an account."
                );

        JPanel card =
                formCard();

        JTextField account =
                field();

        JLabel result =
                new JLabel(
                        "Balance will appear here."
                );

        result.setForeground(
                ACCENT
        );

        result.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        card.add(
                fieldLabel(
                        "Account Number"
                )
        );

        card.add(account);

        card.add(
                Box.createVerticalStrut(
                        18
                )
        );

        JButton check =
                actionButton(
                        "Check Balance"
                );

        check.addActionListener(
                e -> {

                    try {

                        long accountNumber =
                                Long.parseLong(
                                        account.getText()
                                                .trim()
                                );

                        double balance =
                                bank.getBalance(
                                        accountNumber
                                );

                        result.setText(
                                String.format(
                                        "Current Balance: ₹%.2f",
                                        balance
                                )
                        );

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                check
        );

        card.add(
                Box.createVerticalStrut(
                        20
                )
        );

        card.add(
                result
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // TRANSACTION HISTORY
    // =====================================================

    private JPanel createHistoryPanel() {

        JPanel panel =
                basePanel(
                        "Transaction History",
                        "View transactions recorded for an account."
                );

        JPanel card =
                formCard();

        JTextField account =
                field();

        JTextArea output =
                outputArea();

        card.add(
                fieldLabel(
                        "Account Number"
                )
        );

        card.add(account);

        card.add(
                Box.createVerticalStrut(
                        10
                )
        );

        JButton view =
                actionButton(
                        "View History"
                );

        view.addActionListener(
                e -> {

                    try {

                        long accountNumber =
                                Long.parseLong(
                                        account.getText()
                                                .trim()
                                );

                        Account found =
                                bank.searchAccount(
                                        accountNumber
                                );

                        if (
                                found == null
                        ) {

                            throw new Exception(
                                    "Account not found."
                            );
                        }

                        StringBuilder history =
                                new StringBuilder();

                        int count = 1;

                        for (
                                String transaction :
                                found.getTransactions()
                        ) {

                            history.append(
                                    count++
                            );

                            history.append(
                                    ". "
                            );

                            history.append(
                                    transaction
                            );

                            history.append(
                                    "\n"
                            );
                        }

                        if (
                                history.length()
                                        == 0
                        ) {

                            output.setText(
                                    "No transactions available."
                            );

                        } else {

                            output.setText(
                                    history.toString()
                            );
                        }

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                view
        );

        card.add(
                Box.createVerticalStrut(
                        12
                )
        );

        card.add(
                new JScrollPane(
                        output
                )
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // SEARCH ACCOUNT
    // =====================================================

    private JPanel createSearchPanel() {

        JPanel panel =
                basePanel(
                        "Search Account",
                        "Find an account using its account number."
                );

        JPanel card =
                formCard();

        JTextField account =
                field();

        JTextArea output =
                outputArea();

        card.add(
                fieldLabel(
                        "Account Number"
                )
        );

        card.add(account);

        card.add(
                Box.createVerticalStrut(
                        15
                )
        );

        JButton search =
                actionButton(
                        "Search Account"
                );

        search.addActionListener(
                e -> {

                    try {

                        long accountNumber =
                                Long.parseLong(
                                        account.getText()
                                                .trim()
                                );

                        Account found =
                                bank.searchAccount(
                                        accountNumber
                                );

                        if (
                                found == null
                        ) {

                            output.setText(
                                    "Account not found."
                            );

                        } else {

                            output.setText(
                                    found.toString()
                            );
                        }

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                search
        );

        card.add(
                Box.createVerticalStrut(
                        12
                )
        );

        card.add(
                new JScrollPane(
                        output
                )
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // PENDING TRANSFERS
    // =====================================================

    private JPanel createPendingPanel() {

        JPanel panel =
                basePanel(
                        "Pending Transfers",
                        "Add transfers to the queue and process them with multiple threads."
                );

        JPanel card =
                formCard();

        JTextField sender =
                field();

        JTextField receiver =
                field();

        JTextField amount =
                field();

        JTextArea output =
                outputArea();

        card.add(
                fieldLabel(
                        "Sender Account"
                )
        );

        card.add(sender);

        card.add(
                fieldLabel(
                        "Receiver Account"
                )
        );

        card.add(receiver);

        card.add(
                fieldLabel(
                        "Amount"
                )
        );

        card.add(amount);

        card.add(
                Box.createVerticalStrut(
                        15
                )
        );

        JPanel buttons =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT
                        )
                );

        buttons.setOpaque(false);

        JButton add =
                actionButton(
                        "Add to Queue"
                );

        add.addActionListener(
                e -> {

                    try {

                        bank.addPendingTransfer(
                                Long.parseLong(
                                        sender.getText()
                                                .trim()
                                ),
                                Long.parseLong(
                                        receiver.getText()
                                                .trim()
                                ),
                                Double.parseDouble(
                                        amount.getText()
                                                .trim()
                                )
                        );

                        output.append(
                                "Transfer added to pending queue.\n"
                        );

                        sender.setText("");

                        receiver.setText("");

                        amount.setText("");

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        JButton process =
                actionButton(
                        "Process with Threads"
                );

        process.addActionListener(
                e -> {

                    try {

                        bank.processPendingTransfers();

                        output.append(
                                "Pending transfers processed successfully using multithreading.\n"
                        );

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        buttons.add(add);

        buttons.add(process);

        card.add(buttons);

        card.add(
                Box.createVerticalStrut(
                        10
                )
        );

        card.add(
                new JScrollPane(
                        output
                )
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // UNDO
    // =====================================================

    private JPanel createUndoPanel() {

        JPanel panel =
                basePanel(
                        "Undo Last Operation",
                        "Reverse the most recent reversible banking operation."
                );

        JPanel card =
                formCard();

        JLabel information =
                new JLabel(
                        "<html>"
                                + "<b>Undo Operation</b>"
                                + "<br><br>"
                                + "The system can reverse the most recent "
                                + "banking operation."
                                + "</html>"
                );

        information.setForeground(
                TEXT
        );

        information.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        JButton undo =
                actionButton(
                        "Undo Last Operation"
                );

        undo.addActionListener(
                e -> {

                    try {

                        bank.undoLastOperation();

                        success(
                                "Undo operation completed."
                        );

                    } catch (Exception ex) {

                        error(
                                ex.getMessage()
                        );
                    }
                }
        );

        card.add(
                information
        );

        card.add(
                Box.createVerticalStrut(
                        25
                )
        );

        card.add(
                undo
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // ALL ACCOUNTS
    // =====================================================

    private JPanel createAllAccountsPanel() {

        JPanel panel =
                basePanel(
                        "All Accounts",
                        "View accounts currently stored in the banking system."
                );

        JPanel card =
                formCard();

        JTextArea output =
                outputArea();

        JButton refresh =
                actionButton(
                        "Refresh Accounts"
                );

        refresh.addActionListener(
                e -> {

                    StringBuilder result =
                            new StringBuilder();

                    for (
                            long number = 100001;
                            number < 110000;
                            number++
                    ) {

                        Account account =
                                bank.searchAccount(
                                        number
                                );

                        if (
                                account != null
                        ) {

                            result.append(
                                    account
                            );

                            result.append(
                                    "\n\n"
                            );
                        }
                    }

                    if (
                            result.length()
                                    == 0
                    ) {

                        result.append(
                                "No accounts available."
                        );
                    }

                    output.setText(
                            result.toString()
                    );
                }
        );

        card.add(
                refresh
        );

        card.add(
                Box.createVerticalStrut(
                        12
                )
        );

        card.add(
                new JScrollPane(
                        output
                )
        );

        panel.add(
                card,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // COMMON PANEL
    // =====================================================

    private JPanel basePanel(
            String title,
            String subtitle
    ) {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                BACKGROUND
        );

        panel.setBorder(
                new EmptyBorder(
                        30,
                        35,
                        25,
                        35
                )
        );

        JPanel header =
                new JPanel();

        header.setOpaque(false);

        header.setLayout(
                new BoxLayout(
                        header,
                        BoxLayout.Y_AXIS
                )
        );

        JLabel heading =
                new JLabel(
                        title
                );

        heading.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        heading.setForeground(
                TEXT
        );

        JLabel sub =
                new JLabel(
                        subtitle
                );

        sub.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        sub.setForeground(
                SECONDARY
        );

        header.add(
                heading
        );

        header.add(
                Box.createVerticalStrut(
                        5
                )
        );

        header.add(
                sub
        );

        panel.add(
                header,
                BorderLayout.NORTH
        );

        return panel;
    }

    // =====================================================
    // FORM CARD
    // =====================================================

    private JPanel formCard() {

        JPanel card =
                new JPanel();

        card.setBackground(
                Color.WHITE
        );

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        225,
                                        229,
                                        235
                                )
                        ),
                        new EmptyBorder(
                                25,
                                28,
                                25,
                                28
                        )
                )
        );

        card.setLayout(
                new BoxLayout(
                        card,
                        BoxLayout.Y_AXIS
                )
        );

        return card;
    }

    // =====================================================
    // FORM FIELD
    // =====================================================

    private JLabel fieldLabel(
            String text
    ) {

        JLabel label =
                new JLabel(
                        text
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        label.setForeground(
                TEXT
        );

        label.setBorder(
                new EmptyBorder(
                        8,
                        0,
                        5,
                        0
                )
        );

        return label;
    }

    private JTextField field() {

        JTextField field =
                new JTextField();

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        field.setMaximumSize(
                new Dimension(
                        Integer.MAX_VALUE,
                        38
                )
        );

        return field;
    }

    // =====================================================
    // BUTTON
    // =====================================================

    private JButton actionButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                ACCENT
        );

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setBorder(
                new EmptyBorder(
                        11,
                        18,
                        11,
                        18
                )
        );

        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );

        return button;
    }

    // =====================================================
    // TEXT AREA
    // =====================================================

    private JTextArea outputArea() {

        JTextArea output =
                new JTextArea(
                        10,
                        40
                );

        output.setEditable(
                false
        );

        output.setFont(
                new Font(
                        "Consolas",
                        Font.PLAIN,
                        13
                )
        );

        output.setForeground(
                TEXT
        );

        output.setBackground(
                new Color(
                        249,
                        250,
                        251
                )
        );

        output.setLineWrap(
                true
        );

        output.setWrapStyleWord(
                true
        );

        output.setBorder(
                new EmptyBorder(
                        10,
                        10,
                        10,
                        10
                )
        );

        return output;
    }

    // =====================================================
    // SUCCESS MESSAGE
    // =====================================================

    private void success(
            String message
    ) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // =====================================================
    // ERROR MESSAGE
    // =====================================================

    private void error(
            String message
    ) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}