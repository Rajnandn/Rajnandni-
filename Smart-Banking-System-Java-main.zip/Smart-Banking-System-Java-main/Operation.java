public class Operation {

    private final String type;
    private final long account1;
    private final long account2;
    private final double amount;

    private Operation(
            String type,
            long account1,
            long account2,
            double amount) {

        this.type = type;
        this.account1 = account1;
        this.account2 = account2;
        this.amount = amount;
    }

    public static Operation accountCreated(long accountNo) {

        return new Operation(
                "ACCOUNT_CREATED",
                accountNo,
                0,
                0
        );
    }

    public static Operation deposit(
            long accountNo,
            double amount) {

        return new Operation(
                "DEPOSIT",
                accountNo,
                0,
                amount
        );
    }

    public static Operation withdraw(
            long accountNo,
            double amount) {

        return new Operation(
                "WITHDRAW",
                accountNo,
                0,
                amount
        );
    }

    public static Operation transfer(
            long from,
            long to,
            double amount) {

        return new Operation(
                "TRANSFER",
                from,
                to,
                amount
        );
    }

    public String getType() {
        return type;
    }

    public long getAccount1() {
        return account1;
    }

    public long getAccount2() {
        return account2;
    }

    public double getAmount() {
        return amount;
    }
}