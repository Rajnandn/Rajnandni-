import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Bank {

    // ==========================================
    // DSA 1: HASHMAP
    // ==========================================
    // Account number -> Account object
    //
    // Average search time: O(1)
    // ==========================================

    private final HashMap<Long, Account> accounts = new HashMap<>();


    // ==========================================
    // DSA 2: QUEUE
    // ==========================================
    // Pending transactions are processed FIFO.
    // FIFO = First In First Out
    // ==========================================

    private final Queue<TransferRequest> pendingTransfers
            = new LinkedList<>();


    // ==========================================
    // DSA 3: STACK
    // ==========================================
    // Used for undo functionality.
    // LIFO = Last In First Out
    // ==========================================

    private final Stack<Operation> operationStack
            = new Stack<>();


    private long nextAccountNumber = 100001;


    // ==========================================
    // CREATE ACCOUNT
    // ==========================================

    public synchronized void createAccount(
            String name,
            String phone,
            double initialDeposit)
            throws BankingException {

        if (initialDeposit < 0) {

            throw new BankingException(
                    "Initial deposit cannot be negative."
            );
        }

        long accountNo = nextAccountNumber++;

        Account account = new Account(
                accountNo,
                name,
                phone,
                initialDeposit
        );

        accounts.put(accountNo, account);

        account.addTransaction(
                "Account created with initial deposit ₹"
                        + initialDeposit
        );

        operationStack.push(
                Operation.accountCreated(accountNo)
        );

        System.out.println(
                "Account created successfully."
        );

        System.out.println(
                "Your account number is: "
                        + accountNo
        );
    }


    // ==========================================
    // DEPOSIT
    // ==========================================

    public synchronized void deposit(
            long accountNo,
            double amount)
            throws BankingException {

        validateAmount(amount);

        Account account =
                getExistingAccount(accountNo);

        account.deposit(amount);

        account.addTransaction(
                "Deposited ₹" + amount
        );

        operationStack.push(
                Operation.deposit(
                        accountNo,
                        amount
                )
        );

        System.out.printf(
                "₹%.2f deposited successfully.%n",
                amount
        );
    }


    // ==========================================
    // WITHDRAW
    // ==========================================

    public synchronized void withdraw(
            long accountNo,
            double amount)
            throws BankingException {

        validateAmount(amount);

        Account account =
                getExistingAccount(accountNo);

        account.withdraw(amount);

        account.addTransaction(
                "Withdrawn ₹" + amount
        );

        operationStack.push(
                Operation.withdraw(
                        accountNo,
                        amount
                )
        );

        System.out.printf(
                "₹%.2f withdrawn successfully.%n",
                amount
        );
    }


    // ==========================================
    // TRANSFER
    // ==========================================

    public synchronized void transfer(
            long from,
            long to,
            double amount)
            throws BankingException {

        validateAmount(amount);

        if (from == to) {

            throw new BankingException(
                    "Sender and receiver must be different."
            );
        }

        Account sender =
                getExistingAccount(from);

        Account receiver =
                getExistingAccount(to);


        // Withdraw from sender
        sender.withdraw(amount);

        // Deposit into receiver
        receiver.deposit(amount);


        sender.addTransaction(
                String.format(
                        "Transferred ₹%.2f to account %d",
                        amount,
                        to
                )
        );

        receiver.addTransaction(
                String.format(
                        "Received ₹%.2f from account %d",
                        amount,
                        from
                )
        );


        operationStack.push(
                Operation.transfer(
                        from,
                        to,
                        amount
                )
        );


        System.out.printf(
                "₹%.2f transferred successfully.%n",
                amount
        );
    }


    // ==========================================
    // ADD PENDING TRANSFER TO QUEUE
    // ==========================================

    public synchronized void addPendingTransfer(
            long from,
            long to,
            double amount)
            throws BankingException {

        validateAmount(amount);

        getExistingAccount(from);

        getExistingAccount(to);

        pendingTransfers.offer(
                new TransferRequest(
                        from,
                        to,
                        amount
                )
        );

        System.out.println(
                "Transfer added to pending queue."
        );
    }


    // ==========================================
    // MULTITHREADING
    // ==========================================

    public void processPendingTransfers() {

        List<TransferRequest> requests =
                new ArrayList<>();


        // Take transactions out of queue
        synchronized (this) {

            while (!pendingTransfers.isEmpty()) {

                requests.add(
                        pendingTransfers.poll()
                );
            }
        }


        if (requests.isEmpty()) {

            System.out.println(
                    "No pending transfers."
            );

            return;
        }


        // Maximum 4 worker threads
        int threadCount =
                Math.min(4, requests.size());


        ExecutorService executor =
                Executors.newFixedThreadPool(
                        threadCount
                );


        // Submit every transaction as a task
        for (TransferRequest request : requests) {

            executor.submit(() -> {

                try {

                    transfer(
                            request.getFromAccount(),
                            request.getToAccount(),
                            request.getAmount()
                    );


                    System.out.println(
                            "Processed by "
                                    + Thread.currentThread()
                                    .getName()
                                    + " : "
                                    + request
                    );

                } catch (BankingException e) {

                    System.out.println(
                            "Failed by "
                                    + Thread.currentThread()
                                    .getName()
                                    + " : "
                                    + request
                                    + " | "
                                    + e.getMessage()
                    );
                }
            });
        }


        executor.shutdown();


        // Wait until all threads finish
        while (!executor.isTerminated()) {

            try {

                Thread.sleep(50);

            } catch (InterruptedException e) {

                Thread.currentThread().interrupt();

                break;
            }
        }


        System.out.println(
                "All pending transfers processed."
        );
    }


    // ==========================================
    // CHECK BALANCE
    // ==========================================

    public synchronized double getBalance(
            long accountNo)
            throws BankingException {

        return getExistingAccount(accountNo)
                .getBalance();
    }


    // ==========================================
    // SEARCH ACCOUNT
    // ==========================================

    public synchronized Account searchAccount(
            long accountNo) {

        return accounts.get(accountNo);
    }


    // ==========================================
    // DISPLAY ALL ACCOUNTS
    // ==========================================

    public synchronized void displayAllAccounts() {

        if (accounts.isEmpty()) {

            System.out.println(
                    "No accounts available."
            );

            return;
        }


        System.out.println(
                "\n---------- ALL ACCOUNTS ----------"
        );


        for (Account account :
                accounts.values()) {

            System.out.println(account);
        }
    }


    // ==========================================
    // SORT ACCOUNTS
    // ==========================================

    public synchronized void
    displayAccountsSortedByBalance() {

        ArrayList<Account> sorted =
                new ArrayList<>(
                        accounts.values()
                );


        sorted.sort(
                Comparator.comparingDouble(
                        Account::getBalance
                ).reversed()
        );


        System.out.println(
                "\n----- ACCOUNTS SORTED BY BALANCE -----"
        );


        for (Account account : sorted) {

            System.out.printf(
                    "%d | %-20s | ₹%.2f%n",

                    account.getAccountNumber(),

                    account.getName(),

                    account.getBalance()
            );
        }
    }


    // ==========================================
    // TRANSACTION HISTORY
    // ==========================================

    public synchronized void
    showTransactionHistory(
            long accountNo)
            throws BankingException {

        Account account =
                getExistingAccount(accountNo);


        System.out.println(
                "\n----- TRANSACTION HISTORY -----"
        );


        if (account.getTransactions()
                .isEmpty()) {

            System.out.println(
                    "No transactions."
            );

            return;
        }


        int i = 1;


        for (String transaction :
                account.getTransactions()) {

            System.out.println(
                    i++ + ". " + transaction
            );
        }
    }


    // ==========================================
    // UNDO LAST OPERATION
    // ==========================================

    public synchronized void undoLastOperation() {

        if (operationStack.isEmpty()) {

            System.out.println(
                    "Nothing to undo."
            );

            return;
        }


        Operation operation =
                operationStack.pop();


        try {

            switch (operation.getType()) {


                // --------------------------
                // UNDO DEPOSIT
                // --------------------------

                case "DEPOSIT" -> {

                    Account account =
                            getExistingAccount(
                                    operation.getAccount1()
                            );


                    account.withdraw(
                            operation.getAmount()
                    );


                    account.addTransaction(
                            "Undo: deposit of ₹"
                                    + operation.getAmount()
                    );
                }


                // --------------------------
                // UNDO WITHDRAW
                // --------------------------

                case "WITHDRAW" -> {

                    Account account =
                            getExistingAccount(
                                    operation.getAccount1()
                            );


                    account.deposit(
                            operation.getAmount()
                    );


                    account.addTransaction(
                            "Undo: withdrawal of ₹"
                                    + operation.getAmount()
                    );
                }


                // --------------------------
                // UNDO TRANSFER
                // --------------------------

                case "TRANSFER" -> {

                    Account sender =
                            getExistingAccount(
                                    operation.getAccount1()
                            );


                    Account receiver =
                            getExistingAccount(
                                    operation.getAccount2()
                            );


                    receiver.withdraw(
                            operation.getAmount()
                    );


                    sender.deposit(
                            operation.getAmount()
                    );


                    sender.addTransaction(
                            "Undo: transfer of ₹"
                                    + operation.getAmount()
                    );


                    receiver.addTransaction(
                            "Undo: transfer reversal of ₹"
                                    + operation.getAmount()
                    );
                }


                // --------------------------
                // UNDO ACCOUNT CREATION
                // --------------------------

                case "ACCOUNT_CREATED" -> {

                    accounts.remove(
                            operation.getAccount1()
                    );


                    System.out.println(
                            "Last account creation undone."
                    );

                    return;
                }


                default -> System.out.println(
                        "Unknown operation."
                );
            }


            System.out.println(
                    "Last operation undone successfully."
            );


        } catch (BankingException e) {

            System.out.println(
                    "Undo failed: "
                            + e.getMessage()
            );


            operationStack.push(operation);
        }
    }


    // ==========================================
    // FILE HANDLING - SAVE DATA
    // ==========================================

    public synchronized void saveData() {

        try (
                PrintWriter writer =
                        new PrintWriter(
                                new FileWriter(
                                        "accounts.txt"
                                )
                        )
        ) {


            for (Account account :
                    accounts.values()) {

                writer.println(
                        account.getAccountNumber()
                                + "|"
                                + account.getName()
                                + "|"
                                + account.getPhone()
                                + "|"
                                + account.getBalance()
                );
            }


            System.out.println(
                    "Account data saved."
            );


        } catch (IOException e) {

            System.out.println(
                    "Could not save data: "
                            + e.getMessage()
            );
        }
    }


    // ==========================================
    // FILE HANDLING - LOAD DATA
    // ==========================================

    public synchronized void loadData() {

        File file =
                new File("accounts.txt");


        if (!file.exists()) {

            return;
        }


        try (
                BufferedReader reader =
                        new BufferedReader(
                                new FileReader(file)
                        )
        ) {


            String line;


            while (
                    (line = reader.readLine())
                            != null
            ) {


                String[] parts =
                        line.split("\\|", 4);


                if (parts.length != 4) {

                    continue;
                }


                long accountNo =
                        Long.parseLong(parts[0]);


                String name = parts[1];

                String phone = parts[2];

                double balance =
                        Double.parseDouble(parts[3]);


                Account account =
                        new Account(
                                accountNo,
                                name,
                                phone,
                                balance
                        );


                accounts.put(
                        accountNo,
                        account
                );


                nextAccountNumber =
                        Math.max(
                                nextAccountNumber,
                                accountNo + 1
                        );
            }


            System.out.println(
                    "Saved account data loaded."
            );


        } catch (Exception e) {

            System.out.println(
                    "Could not load data: "
                            + e.getMessage()
            );
        }
    }


    // ==========================================
    // HELPER METHODS
    // ==========================================

    private Account getExistingAccount(
            long accountNo)
            throws BankingException {

        Account account =
                accounts.get(accountNo);


        if (account == null) {

            throw new BankingException(
                    "Account "
                            + accountNo
                            + " does not exist."
            );
        }


        return account;
    }


    private void validateAmount(
            double amount)
            throws BankingException {

        if (amount <= 0) {

            throw new BankingException(
                    "Amount must be greater than zero."
            );
        }
    }
}