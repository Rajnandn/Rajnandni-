import java.util.LinkedList;

public class Account {

    private final long accountNumber;
    private final String name;
    private final String phone;
    private double balance;

    // DSA: LinkedList stores transaction history
    private final LinkedList<String> transactions = new LinkedList<>();

    public Account(long accountNumber, String name, String phone, double balance) {

        this.accountNumber = accountNumber;
        this.name = name;
        this.phone = phone;
        this.balance = balance;
    }

    // Synchronized deposit prevents inconsistent balance
    public synchronized void deposit(double amount) {
        balance += amount;
    }

    // Synchronized withdrawal
    public synchronized void withdraw(double amount)
            throws BankingException {

        if (amount > balance) {
            throw new BankingException("Insufficient balance.");
        }

        balance -= amount;
    }

    public synchronized double getBalance() {
        return balance;
    }

    public void addTransaction(String transaction) {

        synchronized (transactions) {
            transactions.add(transaction);
        }
    }

    public LinkedList<String> getTransactions() {
        return transactions;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    @Override
    public String toString() {

        return String.format(
                "Account No: %d | Name: %s | Phone: %s | Balance: ₹%.2f",
                accountNumber,
                name,
                phone,
                balance
        );
    }
}